import EvaluationForm from "@/components/EvaluationForm";

const Index = () => {
  return <EvaluationForm />;
};

export default Index;
